package com.example.belejarmvvmcoroutines.models

data class Movie(val name: String, val imageUrl: String, val category: String)
